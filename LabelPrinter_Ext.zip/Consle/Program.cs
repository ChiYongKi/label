﻿using System;
using RawPrint;
using System.Drawing.Printing;

namespace Consle
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string printerName = "SATO GL412e";
            //printerName = "Samsung X4305 Series (172.16.100.5)";
            //printerName = "EPSON LW-Z900";

            String data = "2022-M-12345 독성학과\n원주경찰서\n2022-01-01(R) 김과장";
            var papers = LabelPaper.PaperList();
            var request = new PrintRequest
            {
                Content = data,
                Title = "2022-S-17104",
                Type = "APSL",
                BarcodeData = data  // "2022-M-12345",
            };
            var printer = new LabelPrinter(printerName);
            printer.BarcodeType = BarcodeType.QR;
            printer.Paper = papers[2];
            var layout = printer.CreateLayout(request);
            printer.Prrint(layout);

        }
    }
}
