﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Raw Print")]
[assembly: AssemblyDescription("Send raw print data directly to printer bypassing the driver.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Frogmore Computer Services Ltd")]
[assembly: AssemblyProduct("Raw Print")]
[assembly: AssemblyCopyright("Copyright Frogmore Computer Services Ltd")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("3839c608-4daa-4a61-b4f9-bec9b6393e3c")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("0.5.0.0")]
[assembly: AssemblyFileVersion("0.5.0.0")]
