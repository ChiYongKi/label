﻿namespace RawPrint
{
    public class PrintRequest
    {
        public string Reference { get; set; }
        public string Content { get; set; }
        public string Type { get; set; }
        public string Title { get; set; }
        public string BarcodeData { get; set; }
        public bool Preview { get; set; } = false;
    }
}