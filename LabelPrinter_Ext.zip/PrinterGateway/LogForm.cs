﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrinterGateway
{
    public partial class LogForm : Form
    {
        public static ListBoxLog listBoxLog;

        public LogForm()
        {
            InitializeComponent();

            listBoxLog = new ListBoxLog(listBox);
        }

        private void LogForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}
