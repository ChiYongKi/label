﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PrinterGateway
{
    [RunInstaller(true)]
    public partial class LabelInstaller : System.Configuration.Install.Installer
    {
        public LabelInstaller()
        {
            InitializeComponent();
        }

        public override void Commit(System.Collections.IDictionary savedState)
        {
            base.Commit(savedState);
            System.Diagnostics.Process.Start(Context.Parameters["TARGETDIR"].ToString() + "PrinterGateway.exe");
            //Remove temp files
            base.Dispose();
        }

        //Delete the file .InstallState (created when using custom actions in setup)
        //Could also delete this after the install (protected override void onAfterInstall) but not tested
        //Source: https://stackoverflow.com/questions/46786297/visual-studio-setup-project-remove-files-created-at-runtime-when-uninstall?rq=1
        public override void Uninstall(IDictionary savedState)
        {
            base.Uninstall(savedState);
            File.Delete(Context.Parameters["TARGETDIR"].ToString() + "PrinterGateway.InstallState");
            //Remove temp files
            base.Dispose();
        }
    }
}
