﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

namespace PrinterGateway
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        private static Mutex _mainMutex;

        [STAThread]
        static void Main()
        {
            if (!SingletonExecute())
            {
                MessageBox.Show("LabelPrinter가 실행중입니다");
                return;
            }
            Spire.Barcode.BarcodeSettings.ApplyKey("MZWLE-PC5Y0-CN8Q7-6NW2V-1UE3Y");

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }

        private static bool SingletonExecute()
        {
            _mainMutex = new Mutex(true, "PrinterGateway", out bool createdNew);
            
            return createdNew;
        }
    }
}
