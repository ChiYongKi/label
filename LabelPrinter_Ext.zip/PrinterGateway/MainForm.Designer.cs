﻿namespace PrinterGateway
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.comboPrinters = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonReload = new System.Windows.Forms.Button();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboApslPrinters = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.radioFull = new System.Windows.Forms.RadioButton();
            this.radioQR = new System.Windows.Forms.RadioButton();
            this.comboPapers = new System.Windows.Forms.ComboBox();
            this.comboApslPapers = new System.Windows.Forms.ComboBox();
            this.buttonLog = new System.Windows.Forms.Button();
            this.testPrint = new System.Windows.Forms.Button();
            this.buttonApslTest = new System.Windows.Forms.Button();
            this.rcptOffset = new System.Windows.Forms.NumericUpDown();
            this.apslOffset = new System.Windows.Forms.NumericUpDown();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.contextMenuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rcptOffset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apslOffset)).BeginInit();
            this.SuspendLayout();
            // 
            // comboPrinters
            // 
            this.comboPrinters.FormattingEnabled = true;
            this.comboPrinters.Location = new System.Drawing.Point(137, 36);
            this.comboPrinters.Name = "comboPrinters";
            this.comboPrinters.Size = new System.Drawing.Size(321, 20);
            this.comboPrinters.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "접수    프린터";
            // 
            // notifyIcon
            // 
            this.notifyIcon.ContextMenuStrip = this.contextMenuStrip;
            this.notifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon.Icon")));
            this.notifyIcon.Text = "Printer Gateway";
            this.notifyIcon.Visible = true;
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem,
            this.ToolStripMenuItem1});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(139, 48);
            this.contextMenuStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.contextMenuStrip_ItemClicked);
            // 
            // ToolStripMenuItem
            // 
            this.ToolStripMenuItem.Name = "ToolStripMenuItem";
            this.ToolStripMenuItem.Size = new System.Drawing.Size(138, 22);
            this.ToolStripMenuItem.Tag = "PRINTER";
            this.ToolStripMenuItem.Text = "프린터 선택";
            // 
            // ToolStripMenuItem1
            // 
            this.ToolStripMenuItem1.Name = "ToolStripMenuItem1";
            this.ToolStripMenuItem1.Size = new System.Drawing.Size(138, 22);
            this.ToolStripMenuItem1.Tag = "EXIT";
            this.ToolStripMenuItem1.Text = "종료";
            // 
            // buttonReload
            // 
            this.buttonReload.Location = new System.Drawing.Point(589, 46);
            this.buttonReload.Name = "buttonReload";
            this.buttonReload.Size = new System.Drawing.Size(96, 23);
            this.buttonReload.TabIndex = 4;
            this.buttonReload.Text = "갱신";
            this.buttonReload.UseMnemonic = false;
            this.buttonReload.UseVisualStyleBackColor = true;
            this.buttonReload.Click += new System.EventHandler(this.buttonReload_Click);
            // 
            // pictureBox
            // 
            this.pictureBox.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox.Location = new System.Drawing.Point(137, 122);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Padding = new System.Windows.Forms.Padding(5);
            this.pictureBox.Size = new System.Drawing.Size(442, 133);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox.TabIndex = 5;
            this.pictureBox.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "증거물 프린터";
            // 
            // comboApslPrinters
            // 
            this.comboApslPrinters.FormattingEnabled = true;
            this.comboApslPrinters.Location = new System.Drawing.Point(137, 65);
            this.comboApslPrinters.Name = "comboApslPrinters";
            this.comboApslPrinters.Size = new System.Drawing.Size(321, 20);
            this.comboApslPrinters.TabIndex = 7;
            this.comboApslPrinters.SelectedIndexChanged += new System.EventHandler(this.comboApslPrinters_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 12);
            this.label4.TabIndex = 8;
            this.label4.Text = "증거물 바코드";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioFull);
            this.panel1.Controls.Add(this.radioQR);
            this.panel1.Location = new System.Drawing.Point(139, 91);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(246, 25);
            this.panel1.TabIndex = 10;
            // 
            // radioFull
            // 
            this.radioFull.AutoSize = true;
            this.radioFull.Location = new System.Drawing.Point(8, 3);
            this.radioFull.Name = "radioFull";
            this.radioFull.Size = new System.Drawing.Size(43, 16);
            this.radioFull.TabIndex = 11;
            this.radioFull.TabStop = true;
            this.radioFull.Text = "Full";
            this.radioFull.UseVisualStyleBackColor = true;
            this.radioFull.Click += new System.EventHandler(this.radioBarcodeType_Click);
            // 
            // radioQR
            // 
            this.radioQR.AutoSize = true;
            this.radioQR.Location = new System.Drawing.Point(59, 3);
            this.radioQR.Name = "radioQR";
            this.radioQR.Size = new System.Drawing.Size(40, 16);
            this.radioQR.TabIndex = 10;
            this.radioQR.TabStop = true;
            this.radioQR.Text = "QR";
            this.radioQR.UseVisualStyleBackColor = true;
            this.radioQR.Click += new System.EventHandler(this.radioBarcodeType_Click);
            // 
            // comboPapers
            // 
            this.comboPapers.FormattingEnabled = true;
            this.comboPapers.Location = new System.Drawing.Point(464, 36);
            this.comboPapers.Name = "comboPapers";
            this.comboPapers.Size = new System.Drawing.Size(74, 20);
            this.comboPapers.TabIndex = 11;
            this.comboPapers.Visible = false;
            this.comboPapers.SelectedIndexChanged += new System.EventHandler(this.comboPapers_SelectedIndexChanged);
            // 
            // comboApslPapers
            // 
            this.comboApslPapers.FormattingEnabled = true;
            this.comboApslPapers.Location = new System.Drawing.Point(464, 65);
            this.comboApslPapers.Name = "comboApslPapers";
            this.comboApslPapers.Size = new System.Drawing.Size(74, 20);
            this.comboApslPapers.TabIndex = 12;
            this.comboApslPapers.Visible = false;
            this.comboApslPapers.SelectedIndexChanged += new System.EventHandler(this.comboApslPapers_SelectedIndexChanged);
            // 
            // buttonLog
            // 
            this.buttonLog.Location = new System.Drawing.Point(589, 232);
            this.buttonLog.Name = "buttonLog";
            this.buttonLog.Size = new System.Drawing.Size(96, 23);
            this.buttonLog.TabIndex = 13;
            this.buttonLog.Text = "Log";
            this.buttonLog.UseMnemonic = false;
            this.buttonLog.UseVisualStyleBackColor = true;
            this.buttonLog.Click += new System.EventHandler(this.buttonLog_Click);
            // 
            // testPrint
            // 
            this.testPrint.Location = new System.Drawing.Point(589, 122);
            this.testPrint.Name = "testPrint";
            this.testPrint.Size = new System.Drawing.Size(96, 23);
            this.testPrint.TabIndex = 14;
            this.testPrint.Text = "접수 테스트";
            this.testPrint.UseMnemonic = false;
            this.testPrint.UseVisualStyleBackColor = true;
            this.testPrint.Click += new System.EventHandler(this.testPrint_Click);
            // 
            // buttonApslTest
            // 
            this.buttonApslTest.Location = new System.Drawing.Point(589, 151);
            this.buttonApslTest.Name = "buttonApslTest";
            this.buttonApslTest.Size = new System.Drawing.Size(96, 23);
            this.buttonApslTest.TabIndex = 15;
            this.buttonApslTest.Text = "증거물 테스트";
            this.buttonApslTest.UseMnemonic = false;
            this.buttonApslTest.UseVisualStyleBackColor = true;
            this.buttonApslTest.Click += new System.EventHandler(this.buttonApslTest_Click);
            // 
            // rcptOffset
            // 
            this.rcptOffset.Location = new System.Drawing.Point(544, 35);
            this.rcptOffset.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.rcptOffset.Name = "rcptOffset";
            this.rcptOffset.Size = new System.Drawing.Size(39, 21);
            this.rcptOffset.TabIndex = 18;
            this.toolTip1.SetToolTip(this.rcptOffset, "cm");
            this.rcptOffset.Visible = false;
            this.rcptOffset.ValueChanged += new System.EventHandler(this.rcptOffset_ValueChanged);
            // 
            // apslOffset
            // 
            this.apslOffset.Location = new System.Drawing.Point(544, 64);
            this.apslOffset.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.apslOffset.Name = "apslOffset";
            this.apslOffset.Size = new System.Drawing.Size(39, 21);
            this.apslOffset.TabIndex = 19;
            this.toolTip2.SetToolTip(this.apslOffset, "cm");
            this.apslOffset.Visible = false;
            this.apslOffset.ValueChanged += new System.EventHandler(this.apslOffset_ValueChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 280);
            this.Controls.Add(this.apslOffset);
            this.Controls.Add(this.rcptOffset);
            this.Controls.Add(this.buttonApslTest);
            this.Controls.Add(this.testPrint);
            this.Controls.Add(this.buttonLog);
            this.Controls.Add(this.comboApslPapers);
            this.Controls.Add(this.comboPapers);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboApslPrinters);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox);
            this.Controls.Add(this.buttonReload);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboPrinters);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "Printer Gateway";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.contextMenuStrip.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rcptOffset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apslOffset)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox comboPrinters;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NotifyIcon notifyIcon;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem1;
        private System.Windows.Forms.Button buttonReload;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboApslPrinters;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton radioFull;
        private System.Windows.Forms.RadioButton radioQR;
        private System.Windows.Forms.ComboBox comboPapers;
        private System.Windows.Forms.ComboBox comboApslPapers;
        private System.Windows.Forms.Button buttonLog;
        private System.Windows.Forms.Button testPrint;
        private System.Windows.Forms.Button buttonApslTest;
        private System.Windows.Forms.NumericUpDown rcptOffset;
        private System.Windows.Forms.NumericUpDown apslOffset;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
    }
}

