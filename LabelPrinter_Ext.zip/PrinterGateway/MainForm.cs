﻿using PrinterGateway.Properties;
using RawPrint;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

namespace PrinterGateway
{
    public partial class MainForm : Form
    {
        private static Settings SETTINGS = Settings.Default;

        //public static ListBoxLog listBoxLog;
        private readonly HttpServer httpServer;
        private LabelPrinter currentPrinter;
        private LabelPrinter currentApslPrinter;
        private ComboHelper cmbPrinters;
        private ComboHelper cmbApslPrinters;
        private ComboHelper cmbPapers;
        private ComboHelper cmbApslPapers;
        private LogForm logForm;

        private bool _systemShutdown;

        public MainForm()
        {
            InitializeComponent();
            //listBoxLog = new ListBoxLog(listBox);
            logForm = new LogForm();
            httpServer = new HttpServer(SETTINGS.ListeningUrl);
            httpServer.PrintRequested += PrintRequested;

            cmbPrinters = new ComboHelper(comboPrinters, comboPrinters_SelectedIndexChanged, "DefaultPrinter", ListPrinters);
            cmbApslPrinters = new ComboHelper(comboApslPrinters, comboApslPrinters_SelectedIndexChanged, "DefaultApslPrinter", ListPrinters);
            cmbPapers = new ComboHelper(comboPapers, comboPapers_SelectedIndexChanged, "DefaultPaper", LabelPaper.PaperList);
            cmbApslPapers = new ComboHelper(comboApslPapers, comboApslPapers_SelectedIndexChanged, "DefaultApslPaper", LabelPaper.PaperList);
        }


        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_systemShutdown)
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
                this.Visible = false;
            }
        }

        private void contextMenuStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem.Tag != null && e.ClickedItem.Tag.ToString().Equals("EXIT"))
            {
                _systemShutdown = true;
                httpServer.Close();
                this.Close();
                this.Dispose();
                Application.Exit();
            }
            else
            {
                this.Visible = true;
                if(this.WindowState == FormWindowState.Minimized) {
                    this.WindowState = FormWindowState.Normal;

                }
                this.Activate();
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadPrinters();
            httpServer.Start();
            // 시작할 때 팝을 띄우지 않도록 한다. 2023.09.06
            this.WindowState = FormWindowState.Minimized;
            this.ShowInTaskbar = false;
        }

        private void PrintRequested(object sender, PrintRequestEventArgs e)
        {
            var printer = e.Request.Type == "APSL" ? currentApslPrinter : currentPrinter;
            if (printer != null)
            {
                using (PrintLayout layout = printer.CreateLayout(e.Request))
                {
                    pictureBox.Invoke((MethodInvoker)delegate
                    {
                        if (pictureBox.Image != null)
                        {
                            pictureBox.Image.Dispose();
                        }
                        pictureBox.Image = layout.BarcodeImage; // ..Clone(
                                                  //new Rectangle(0, 0, image.Width, image.Height),
                                                  //System.Drawing.Imaging.PixelFormat.DontCare);
                    });
                    printer.Prrint(layout, this);

                    e.Response.Printer = printer.Name;
                    e.Response.Status = "OK";
                }
            }
        }

        private void comboPrinters_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbPrinters.Save(SETTINGS);
            SetCurrent();
        }

        private void comboApslPrinters_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbApslPrinters.Save(SETTINGS);
            SetCurrent();
        }

        private void comboPapers_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selected = cmbPapers.Save(SETTINGS) as LabelPaper;
            //this.currentPrinter.Paper = selected;
        }

        private void comboApslPapers_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selected = cmbApslPapers.Save(SETTINGS) as LabelPaper;
            //this.currentApslPrinter.Paper = selected;
        }

        private void buttonReload_Click(object sender, EventArgs e)
        {
            LoadPrinters();
        }

        public List<InstalledPrinter> ListPrinters()
        {
            return Printer.EnumeratePrinters()
                .Select(p => new InstalledPrinter { Name = p.pPrinterName, DriverName = p.pDriverName })
                .ToList();
        }

        private void LoadPrinters()
        {
            cmbPrinters.Bind(SETTINGS);
            cmbPapers.Bind(SETTINGS);

            cmbApslPrinters.Bind(SETTINGS);
            cmbApslPapers.Bind(SETTINGS);
            rcptOffset.Value = SETTINGS.RcptOffset;
            apslOffset.Value = SETTINGS.ApslOffset;

            if (SETTINGS.APSLBarcodeType == BarcodeType.QR.ToString())
            {
                radioQR.Checked = true;
            }
            else
            {
                radioFull.Checked = true;
            }

            SetCurrent();
        }

        private void SetCurrent()
        {
            var printer = comboPrinters.SelectedItem as InstalledPrinter;
            this.currentPrinter = LabelPrinterFactory.Create(printer.Name, printer.DriverName);
           // this.currentPrinter.Paper = comboPapers.SelectedItem as LabelPaper;
            this.currentPrinter.PaperSizeOffset = (int)rcptOffset.Value;

            var apslPrinter = comboApslPrinters.SelectedItem as InstalledPrinter;
            var barcodeType = radioQR.Checked ? BarcodeType.QR : BarcodeType.PDF417;

            this.currentApslPrinter = LabelPrinterFactory.Create(apslPrinter.Name, apslPrinter.DriverName);
            this.currentApslPrinter.BarcodeType = barcodeType;
          //  this.currentApslPrinter.Paper = comboApslPapers.SelectedItem as LabelPaper;
            this.currentApslPrinter.PaperSizeOffset = (int)apslOffset.Value;

           // this.toolTip1.ToolTipTitle = string.Format("{0}", 0.254f * (currentPrinter.Paper.PageSize.Height + currentPrinter.PaperSizeOffset));
          //  this.toolTip2.ToolTipTitle = string.Format("{0}", 0.254f* (currentApslPrinter.Paper.PageSize.Height + currentApslPrinter.PaperSizeOffset));
        }

        private void radioBarcodeType_Click(object sender, EventArgs e)
        {
            if (currentApslPrinter != null)
            {
                var barcodeType = radioQR.Checked ? BarcodeType.QR : BarcodeType.PDF417;
                currentApslPrinter.BarcodeType = barcodeType;
                SETTINGS.APSLBarcodeType = barcodeType.ToString();
                SETTINGS.Save();
            }
        }

        private void testPrint_Click(object sender, EventArgs e)
        {
            PrintRequestEventArgs evt = new PrintRequestEventArgs
            {
                Request = new PrintRequest
                {
                    Type = "RCPT",
                    Reference = "test-print",
                    Preview = true,
                    Title = "2022-M-12345",
                    Content = "2022-M-12345 독성학과\n원주경찰서\n2022-01-01(R) 김과장",
                    BarcodeData = "2022-M-12345"
                },
                Response = new PrintResponse()
            };
            PrintRequested(this, evt);
        }

        private void buttonApslTest_Click(object sender, EventArgs e)
        {
            PrintRequestEventArgs evt = new PrintRequestEventArgs
            {
                Request = new PrintRequest
                {
                    Type = "APSL",
                    Reference = "test-print",
                    Preview = true,
                    Title = "2022-M-12345",
                    Content = "독성학과\n원주경찰서\n2022-01-01(R) 김과장",
                    BarcodeData = "2022-M-12345 원주경찰서 2022-01-01(R) 김과장"
                },
                Response = new PrintResponse()
            };
            PrintRequested(this, evt);
        }

        private void buttonLog_Click(object sender, EventArgs e)
        {
            logForm.Show(this);
        }

        private void rcptOffset_ValueChanged(object sender, EventArgs e)
        {
            SETTINGS.RcptOffset = (int) rcptOffset.Value;
            SETTINGS.Save();
            SetCurrent();
        }

        private void apslOffset_ValueChanged(object sender, EventArgs e)
        {
            SETTINGS.ApslOffset = (int)apslOffset.Value;
            SETTINGS.Save();
            SetCurrent();
        }
    }

    public class InstalledPrinter
    {
        public string Name { get; set; }
        public string DriverName { get; set; }
    }

    public delegate object Supplier();

    public class ComboHelper
    {
        protected readonly ComboBox combo;
        private readonly EventHandler handler;
        private readonly string settingKey;
        private readonly Supplier supplier;

        internal ComboHelper(ComboBox combo, EventHandler handler, string settingKey, Supplier supplier)
        {
            this.combo = combo;
            this.handler = handler;
            this.settingKey = settingKey;
            this.supplier = supplier;
        }

        internal void Bind(Settings settings)
        {
            string selected = settings[settingKey] as string;
            combo.SelectedIndexChanged -= handler;
            combo.DataSource = supplier();
            combo.DisplayMember = "Name";
            combo.ValueMember = "Name";
            combo.SelectedValue = selected;

            if ((combo.SelectedIndex < 0 || String.IsNullOrEmpty(selected)) && combo.Items.Count > 0)
            {
                combo.SelectedIndex = 0;

                settings[settingKey] = this.combo.SelectedValue;
                settings.Save();
            }

            combo.SelectedIndexChanged += handler;
        }

        internal object Save(Settings settings)
        {
            settings[settingKey] = this.combo.SelectedValue;
            settings.Save();

            return this.combo.SelectedItem;
        }
    }
}
