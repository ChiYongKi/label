﻿using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;

namespace RawPrint
{
    public enum BarcodeType
    {
        CODE39,
        PDF417,
        QR,
    }

    public class BarcodeSize
    {
        public BarcodeType BarcodeType { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }

        public int MaxLine { get; set; } = 3;

        public int MaxLineChars { get; set; } = 32;
    }

    public class LabelPaper
    {
        public string Name { get; set; }

        public string TitleFontName { get; set; } = "맑은 고딕"; // "돋움체";

        public int TitleFontSize { get; set; }

        public string ContentFontName { get; set; } = "맑은 고딕"; // "돋움체";

        public int ContentFontSize { get; set; }

        public BarcodeSize[] BarcodeSizes { get; set; }

        public bool SingleLine { get; set; } = false;

        public float? ContentWidth { get; set; }

        public Margins Margins { get; set; } = new Margins(20, 16, 10, 16);

        public int DefaultXOffset { get; set; } = 5;
        public int DefaultYOffset { get; set; } = 5;

        public int DefaultTitleXOffset { get; set;  } = 3;

        public PaperSize PageSize { get; private set; }

        public static List<LabelPaper> PaperList()
        {
            return new List<LabelPaper>
            {
                new LabelPaper {Name = "70 x 50", TitleFontSize = 22, ContentFontSize = 12, DefaultYOffset=10, PageSize = new PaperSize("C7050", 276, 200),
                    BarcodeSizes = new BarcodeSize[] {
                        new BarcodeSize {BarcodeType = BarcodeType.CODE39, Width = 200, Height = 40},
                        new BarcodeSize {BarcodeType = BarcodeType.PDF417, Width = 240, Height = 45},
                        new BarcodeSize {BarcodeType = BarcodeType.QR, Width = 50, Height = 50},
                    } },
                new LabelPaper {Name = "55 x 25", TitleFontSize = 13, ContentFontSize = 8, Margins = new Margins(10, 10, 3, 3), PageSize = new PaperSize("C5525", 216, 98),
                    BarcodeSizes = new BarcodeSize[] {
                        new BarcodeSize {BarcodeType = BarcodeType.CODE39, Width = 180, Height = 25},
                        new BarcodeSize {BarcodeType = BarcodeType.PDF417, Width = 180, Height = 25},
                        new BarcodeSize {BarcodeType = BarcodeType.QR, Width = 50, Height = 50, MaxLine = 4, MaxLineChars=17},
                    } },
                /*
                new LabelPaper {Name = "Line x 12", TitleFontSize = 12, ContentWidth = 120 / 2.54f, ContentFontSize = 8, Margins = new Margins(3, 3, 3, 3), PageSize = new PaperSize("CX24", 100, 94),
                    BarcodeSizes = new BarcodeSize[] {
                        new BarcodeSize {BarcodeType = BarcodeType.CODE39, Width = 160 , Height = 35},
                        new BarcodeSize {BarcodeType = BarcodeType.PDF417, Width = 160, Height = 35},
                        new BarcodeSize {BarcodeType = BarcodeType.QR, Width = 40, Height = 40},
                    } },
                */
            };
        }
    }

}
