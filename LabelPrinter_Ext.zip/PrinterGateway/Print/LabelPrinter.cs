﻿using PrinterGateway;
using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Windows.Forms; 

namespace RawPrint
{
    public class LabelPrinter
    {
        public string Name { get; }
        public BarcodeType BarcodeType { get;  set; } = BarcodeType.CODE39;
        //public LabelPaper Paper { get; set; }
        public int PaperSizeOffset { get; internal set; } = 0;


        public LabelPrinter(string printerName)
        {
            this.Name = printerName;
        }

        public void Prrint(PrintLayout layout, MainForm mainForm)
        {
            PrintDocument pd = new PrintDocument();
            PrinterSettings printerSettings = new PrinterSettings();
            //printerSettings.DefaultPageSettings.Margins = Paper.Margins;
            if (layout.ContentLength.HasValue)
            {
                //printerSettings.DefaultPageSettings.PaperSize = new PaperSize("CustomVariable", (int) Paper.ContentWidth.Value, (int) layout.ContentLength.Value);
            }
            else
            {
                //printerSettings.DefaultPageSettings.PaperSize = new PaperSize(Paper.PageSize.PaperName, Paper.PageSize.Width, PaperSizeOffset + Paper.PageSize.Height);
            }

            printerSettings.PrinterName = Name;
            LabelPaper paper = FindPaper(printerSettings);

            layout.SetPaper(paper);
            printerSettings.DefaultPageSettings.Margins = paper.Margins;

            pd.PrinterSettings = printerSettings;
            pd.OriginAtMargins = true;

            pd.PrintPage += new PrintPageEventHandler((sender, e) => layout.Print(e));
            pd.BeginPrint += Pd_BeginPrint;
            pd.EndPrint += Pd_EndPrint;

            if (layout.Preview)
            {
                PrintPreviewDialog printpreview = new PrintPreviewDialog();
                printpreview.Owner = mainForm;

                printpreview.Document = pd;
                DialogResult result = printpreview.ShowDialog();
                if (result == DialogResult.OK)
                {
                    LogForm.listBoxLog.Log(Level.Info, "Preview OK");
                }
                else
                {
                    LogForm.listBoxLog.Log(Level.Info, "Preview Canceled");
                }
            }
            else
            {
                pd.PrintController = new StandardPrintController(); // no UI
                pd.Print();
            }
        }

        private LabelPaper FindPaper(PrinterSettings printerSettings)
        {
            foreach (LabelPaper paper in LabelPaper.PaperList()) {
                if (paper.PageSize.Height <= printerSettings.DefaultPageSettings.Bounds.Height)
                {
                    return paper;
                }
            }
            return LabelPaper.PaperList().Last();
        }

        private void Pd_EndPrint(object sender, PrintEventArgs e)
        {
            LogForm.listBoxLog.Log(Level.Info, "EndPrint " + e.PrintAction);
        }

        private void Pd_BeginPrint(object sender, PrintEventArgs e)
        {
            LogForm.listBoxLog.Log(Level.Info, "BeginPrint " + e.PrintAction);
        }

        public PrintLayout CreateLayout(PrintRequest request)
        {
           // if (Paper.SingleLine)
           // {
          //      return new SingleLineLayout(this, request);
           // }
            if (BarcodeType == BarcodeType.QR)
            {
                return new QRPrintLayout(this, request);
            }
            return new DefaultPrintLayout(this, request);
        }

        internal Size GetBarcodeSizeDimension(LabelPaper paper)
        {
            var bs = paper.BarcodeSizes[(int) BarcodeType];
            return new Size(bs.Width, bs.Height);
        }

        internal BarcodeSize GetBarcodeSize(LabelPaper paper)
        {
            return paper.BarcodeSizes[(int)BarcodeType];
        }
    }

    
    public class LabelPrinterFactory
    {
        public static LabelPrinter Create(string printerName, string driverName)
        {
            return new LabelPrinter(printerName);
        }

    }
}
