﻿using Spire.Barcode;
using System;
using System.Drawing.Printing;
using System.Drawing;
using ZXing.OneD;
using ZXing.PDF417;
using System.Drawing.Drawing2D;
using ZXing.QrCode;
using ZXing.QrCode.Internal;
using System.Text;

namespace RawPrint
{
    public abstract class PrintLayout : IDisposable
    {
        protected Font TitleFont { get; private set; }
        protected Font ContentFont { get; private set; }

        protected readonly LabelPrinter printer;
        protected readonly PrintRequest request;
        public Size BarcodeDimension { get; private set; }
        public Image BarcodeImage { get; private set; }
        public bool Preview { get; }
        public float? ContentLength { get; protected set; }
        public float? ContentHeight { get; protected set; }
        public int DefaultXOffset { get; protected set; }
        public int DefaultYOffset { get; protected set; }

        public int DefaultTitleXOffset { get; private set; }
        public int MaxLine { get; protected set; }
        public int MaxLineChars { get; protected set; }

        public PrintLayout(LabelPrinter printer, PrintRequest request)
        {
            this.printer = printer;
            this.request = request;
            this.Preview = request.Preview;
        }

        public void SetPaper(LabelPaper paper)
        {
            this.TitleFont = new Font(paper.TitleFontName, paper.TitleFontSize, FontStyle.Bold );
            this.ContentFont = new Font(paper.ContentFontName, paper.ContentFontSize, FontStyle.Regular);
            this.DefaultXOffset =paper.DefaultXOffset;
            this.DefaultYOffset = paper.DefaultYOffset;
            this.DefaultTitleXOffset = paper.DefaultTitleXOffset;
            this.MaxLine = printer.GetBarcodeSize(paper).MaxLine;
            this.MaxLineChars = printer.GetBarcodeSize(paper).MaxLineChars;
            this.BarcodeDimension = printer.GetBarcodeSizeDimension(paper);
            this.BarcodeImage = CreateBarcode(BarcodeDimension, request);
        }

        private Image CreateBarcode(Size size, PrintRequest request)
        {
            switch (printer.BarcodeType)
            {
                case BarcodeType.QR:
                    return CreateQR(request.BarcodeData, size.Width, size.Height);
                case BarcodeType.PDF417:
                    return CreatePDF417Z(request.BarcodeData, size.Width, size.Height);
                default:
                    return CreateCode39(request.BarcodeData, size.Width, size.Height);
            }
        }

        private Image CreateQR(string data, int width, int height)
        {
            BarcodeSettings settings = new BarcodeSettings();
            settings.Type = BarCodeType.QRCode;
            settings.QRCodeDataMode = QRCodeDataMode.Auto;

            settings.Unit = GraphicsUnit.Pixel;
            settings.Data = data;
            settings.LeftMargin = 0;
            settings.RightMargin = 0;
            settings.TopMargin = 0;
            settings.BottomMargin = 0;

            settings.ResolutionType = ResolutionType.Graphics;
            settings.ShowText = false;

            settings.X = 2;// width; // 25.0f;

            settings.QRCodeECL = QRCodeECL.M;

            BarCodeGenerator generator = new BarCodeGenerator(settings);
            Image image = generator.GenerateImage();
            return image;
        }

        private Image CreateCode39(string data, int width, int height)
        {
            BarcodeSettings settings = new BarcodeSettings();
            settings.Type = BarCodeType.Code39;

            settings.Data = data;
            settings.ResolutionType = ResolutionType.Graphics;
            //settings.AutoResize = false;
            settings.LeftMargin = 0;
            settings.RightMargin = 0;
            settings.TopMargin = 0;
            settings.BottomMargin = 0;
            settings.ShowText = false;
            settings.Unit = GraphicsUnit.Pixel;
            settings.BarHeight = height;
            settings.ImageHeight = height;
            settings.ImageWidth = width;
            settings.X = 1f; // width / 224.0f;
            BarCodeGenerator generator = new BarCodeGenerator(settings);
            Image image = generator.GenerateImage();
            //image.Save("barcode.png");

            return image;
        }

        public Image CreateCode39Z(string data, int width, int height)
        {
            var margin = 1;
            var qrCodeWriter = new ZXing.BarcodeWriterPixelData
            {
                Format = ZXing.BarcodeFormat.CODE_128,
                Options = new Code128EncodingOptions
                {
                    Height = height,
                    Width = 0,
                    Margin = margin,
                    // PureBarcode = true
                }
            };
            var pixelData = qrCodeWriter.Write(data);

            var bitmap = pixelData.ToBitmap();
            return bitmap;
        }

        public Image CreateQRZ(string data, int width, int height)
        {
            float ratio = width / height;
            var margin = 0;
            var qrCodeWriter = new ZXing.BarcodeWriterPixelData
            {
                Format = ZXing.BarcodeFormat.QR_CODE,
                Options = new QrCodeEncodingOptions
                {
                    CharacterSet = "UTF-8",
                    Margin = margin,
                    Height = height,
                    Width = width,
                    ErrorCorrection = ErrorCorrectionLevel.M,
                }

            };
            var pixelData = qrCodeWriter.Write(data);

            var bitmap = pixelData.ToBitmap();
            return bitmap;
        }

        public Image CreatePDF417Z(string data, int width, int height)
        {
            float ratio = width / height;
            var margin = 0;
            var qrCodeWriter = new ZXing.BarcodeWriterPixelData
            {
                Format = ZXing.BarcodeFormat.PDF_417,
                Options = new PDF417EncodingOptions
                {
                    CharacterSet = "UTF-8",
                    Margin = margin,
                    ImageAspectRatio = ratio,
                    //ErrorCorrection = ZXing.PDF417.Internal.PDF417ErrorCorrectionLevel.L5,
                }
            };
            var pixelData = qrCodeWriter.Write(data);

            var bitmap = pixelData.ToBitmap();
            return bitmap;
        }

        private Bitmap ScaleImage(Image source, int maxWidth, int maxHeight)
        {
            var newSize = ScaleSize(source, new Size(maxWidth, maxHeight));
            var newImage = new Bitmap(newSize.Width, newSize.Height);//, PixelFormat.Format32bppRgb);
            using (var graphics = Graphics.FromImage(newImage))
            {
                SetHighQuality(graphics);
                graphics.DrawImage(source, 0, 0, newSize.Width, newSize.Height);
            }
            source.Dispose();
            return newImage;
        }

        protected Size ScaleSize(Image source, Size size)
        {
            var ratioX = (double)size.Width / source.Width;
            var ratioY = (double)size.Height / source.Height;
            var ratio = Math.Min(ratioX, ratioY);
            var newWidth = (int)(source.Width * ratio);
            var newHeight = (int)(source.Height * ratio);
            
            return new Size(newWidth, newHeight);
        }

        private void SetHighQuality(Graphics graphics)
        {
            graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
            graphics.CompositingQuality = CompositingQuality.HighQuality;
            graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            graphics.SmoothingMode = SmoothingMode.HighQuality;
            graphics.CompositingQuality = CompositingQuality.HighQuality;
        }

        public virtual void Print(PrintPageEventArgs e)
        {
            e.HasMorePages = false;
            string[] contents = request.Content.Split('\n');
            var builder = new StringBuilder();
            int outLines = 0;
            for (int i = 0; outLines < MaxLine && i < contents.Length; i++)
            {
                string line = contents[i].Trim();
                int size = line.Length;
                if (size > MaxLineChars)
                {
                    while (size > 0 && outLines < MaxLine)
                    {
                        int sub = Math.Min(size, MaxLineChars);
                        builder.AppendLine(line.Substring(0, sub));
                        line = line.Substring(sub).Trim();
                        size = line.Length;
                        outLines += 1;
                    }
                }
                else {
                    builder.AppendLine(line);
                    outLines += 1;
                }
            }
            request.Content = builder.ToString();

            SetHighQuality(e.Graphics);
        }

        public void Dispose()
        {
            //BarcodeImage.Dispose();
        }
    }

    public class DefaultPrintLayout : PrintLayout
    {
        public DefaultPrintLayout(LabelPrinter printer, PrintRequest request) : base(printer, request)
        {
        }

        public override void Print(PrintPageEventArgs e)
        {
            base.Print(e);

            int width = e.MarginBounds.Width;
            int height = e.MarginBounds.Height;
            Size newSize = BarcodeDimension; // printer.GetBarcodeSizeDimension();

            e.Graphics.DrawString(request.Title, TitleFont, Brushes.Black, DefaultTitleXOffset, 0);
            e.Graphics.DrawString(request.Content, ContentFont, Brushes.Black, DefaultXOffset, height * 0.26f);
            e.Graphics.DrawImage(BarcodeImage, DefaultXOffset, height * 0.75f, newSize.Width, newSize.Height);
        }
    }

    public class QRPrintLayout : PrintLayout
    {
        public QRPrintLayout(LabelPrinter printer, PrintRequest request) : base(printer, request)
        {
            MaxLine = 4;
        }

        public override void Print(PrintPageEventArgs e)
        {
            base.Print(e);

            int width = e.MarginBounds.Width;
            int height = e.MarginBounds.Height;
            float lineHeight = height * 0.7f;
            Size newSize = BarcodeDimension; // printer.GetBarcodeSizeDimension();

            e.Graphics.DrawString(request.Content, ContentFont, Brushes.Black, DefaultXOffset, DefaultYOffset);
            e.Graphics.DrawLine(Pens.Black, 0, lineHeight, width, lineHeight);

            e.Graphics.DrawString(request.Title, TitleFont, Brushes.Black, DefaultXOffset, lineHeight + 0.5f);

            e.Graphics.DrawImage(BarcodeImage, width - newSize.Width, 3, newSize.Width, newSize.Height);

            //e.Graphics.DrawImage(BarcodeImage, new Rectangle(width - newSize.Width - 5, 0, newSize.Width, newSize.Height), 0, 0, BarcodeImage.Width, BarcodeImage.Height, GraphicsUnit.Pixel);
        }
    }

    public class SingleLineLayout : PrintLayout
    {
        public SingleLineLayout(LabelPrinter printer, PrintRequest request) : base(printer, request)
        {
            string content = BuildContent(request);
            SizeF size = MeasureString(content, ContentFont);
            //ContentLength = size.Width + printer.GetBarcodeSize().Width + 35;
            ContentHeight = size.Height;
        }

        public override void Print(PrintPageEventArgs e)
        {
            base.Print(e);

            int width = e.MarginBounds.Width;
            int height = (e.MarginBounds.Height - (int) ContentHeight.Value) / 2;

            string content = BuildContent(request);
            e.Graphics.DrawString(content, ContentFont, Brushes.Black, 0, height);

            //e.Graphics.DrawImage(BarcodeImage, ContentLength.Value - printer.GetBarcodeSize().Width - 8, 0, printer.GetBarcodeSize().Width, printer.GetBarcodeSize().Height);
        }

        internal static SizeF MeasureString(string content, Font font)
        {
            Graphics gfx = Graphics.FromImage(new Bitmap(1, 1));
            return gfx.MeasureString(content, font);
        }

        private static string BuildContent(PrintRequest request)
        {
            return String.Format("{0} {1}", request.Title, request.Content.Replace(Environment.NewLine, " ").Replace("\n", ""));
        }
    }

}
