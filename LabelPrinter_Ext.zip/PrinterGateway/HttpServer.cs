﻿using Newtonsoft.Json;
using PrinterGateway.Properties;
using RawPrint;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace PrinterGateway
{
    internal class HttpServer
    {
        private static Settings SETTINGS = Settings.Default;

        private readonly TraceSource logEventSource;

        private readonly HttpListener listener;
        private readonly string url;

        public event EventHandler<PrintRequestEventArgs> PrintRequested;

        internal HttpServer(string url)
        {
            this.url = url;
            listener = new HttpListener();
            listener.Prefixes.Add(url);

            EventLogTraceListener traceListener = new EventLogTraceListener("PrinterGateway");
            this.logEventSource = new TraceSource("PrinterGateway");
            this.logEventSource.Switch = new SourceSwitch("PrinterGateway");
            this.logEventSource.Switch.Level = SourceLevels.All;
            this.logEventSource.Listeners.Add(traceListener);
        }

        public Task Start()
        {
            listener.Start();
            Log("Listening for connections on {0}", url);

            return HandleIncomingConnections();
        }

        private void Log(string fmt, params object[] args)
        {
            Log(Level.Info, fmt, args);
        }

        private void LogError(string fmt, params object[] args)
        {
            Log(Level.Error, fmt, args);
        }

        private void Log(Level logLevel, string fmt, params object[] args)
        {
            LogForm.listBoxLog.Log(logLevel, fmt, args);
        }

        protected virtual void OnPrintRequested(PrintRequestEventArgs e)
        {
            if (PrintRequested != null)
            {
                PrintRequested.Invoke(this, e);
            }
        }

        public  async Task HandleIncomingConnections()
        {
            bool runServer = true;

            // While a user hasn't visited the `shutdown` url, keep on handling requests
            while (runServer)
            {
                // Will wait here until we hear from a connection
                HttpListenerContext ctx = await listener.GetContextAsync();

                // Peel out the requests and response objects
                HttpListenerRequest req = ctx.Request;
                HttpListenerResponse resp = ctx.Response;
                resp.ContentType = "application/json";
                resp.Headers["Access-Control-Allow-Origin"] = "*";

                // Print out some info about the request
                Log("{0} {1}", req.HttpMethod, req.Url);

                string data = null;
                if (req.HttpMethod == "OPTIONS")
                {
                    resp.Headers["Access-Control-Allow-Methods"] = "POST, GET, OPTIONS";
                    resp.Headers["Access-Control-Max-Age"] = "1000";
                    resp.Headers["Access-Control-Allow-Headers"] = "origin, x-csrftoken, content-type, accept";
                }
                else if ((req.HttpMethod == "POST") && (req.Url.AbsolutePath == "/print"))
                {
                    if (req.HasEntityBody)
                    {
                        try {
                            long length = req.ContentLength64;

                            using (var memoryStream = new MemoryStream())
                            {
                                var buffer = new byte[8192];
                                while (length > 0)
                                {
                                    int read = req.InputStream.Read(buffer, 0, (int) Math.Min(buffer.Length, length));

                                    if (read <= 0)
                                    {
                                        break;
                                    }
                                    memoryStream.Write(buffer, 0, read);
                                    length -= read;
                                }

                                memoryStream.Flush();

                                var content = memoryStream.ToArray();
                                Log("{0} {1} {2} Content Byte Length: {3}", req.HttpMethod, req.Url, req.ContentType, content.Length);

                                var request = ParsePrintRequest(req.ContentType, content);
                                PrintResponse response = new PrintResponse { Reference = request.Reference };

                                if (request.Title != null && request.Content != null && request.BarcodeData != null)
                                {
                                    
                                    OnPrintRequested(new PrintRequestEventArgs
                                    {
                                        Request = request,
                                        Response = response
                                    });
                                }
                                else
                                {
                                    resp.StatusCode = (int)HttpStatusCode.BadRequest;
                                }
                                data = JsonConvert.SerializeObject(response);
                            }
                        }  
                        catch (Exception ex)
                        {
                            LogError("{0} {1} {2}", ex.Message, Environment.NewLine, ex.StackTrace.ToString());
                            resp.StatusCode = (int)HttpStatusCode.InternalServerError;
                            data = JsonConvert.SerializeObject(new ErrorResponse { Message = ex.Message });
                        }
                    }
                    else
                    {
                        Log("{0} {1} {2}", req.HttpMethod, req.Url, "NO CONTENT");
                    }
                }
                else if ((req.HttpMethod == "GET") && (req.Url.AbsolutePath == "/"))
                {
                    data = DefaultPage(resp);
                }
                else if ((req.HttpMethod == "GET") && (req.Url.AbsolutePath == "/status"))
                {
                    data = StatusPage(resp);
                }
                else if ((req.HttpMethod == "GET") && (req.Url.AbsolutePath == "/printers/"))
                {
                    data = ListPrinters(resp);
                }
                else
                {
                    resp.StatusCode = (int) HttpStatusCode.NotFound;
                    Log("{0} {1} {2}", req.HttpMethod, req.Url, "NOT FOUND");
                }

                // Write the response info
                if (data != null)
                {
                    resp.ContentEncoding = Encoding.UTF8;
                    byte[] output = Encoding.UTF8.GetBytes(data);
                    resp.ContentLength64 = output.LongLength;
                    await resp.OutputStream.WriteAsync(output, 0, output.Length);
                }

                // Write out to the response stream (asynchronously), then close it
                resp.Close();
                Log("{0} {1} {2}", req.HttpMethod, req.Url, "FINISHED");

            }
        }

        private PrintRequest ParsePrintRequest(string contentType, byte[] body)
        {
            if (contentType.StartsWith("application/json"))
            {
                return JsonConvert.DeserializeObject<PrintRequest>(Encoding.UTF8.GetString(body));
            }
            else
            {
                var collection = HttpUtility.ParseQueryString(Encoding.UTF8.GetString(body), Encoding.UTF8);
                return new PrintRequest
                {
                    Content = collection["Content"],
                    Type = collection["Type"],
                    Title = collection["Title"],
                    BarcodeData = collection["BarcodeData"],
                    Preview = bool.Parse(collection["Preview"]),

                    Reference = collection["Reference"]
                };
            }
        }

        private string ListPrinters(HttpListenerResponse resp)
        {
            var printers = Printer.EnumeratePrinters();
            var printerNames = printers.Select(info => info.pPrinterName);
            
            return JsonConvert.SerializeObject(printerNames);
        }

        private static string StatusPage(HttpListenerResponse resp)
        {
            string pageData = "{\"Status\" : \"OK\"}";
            return pageData;
        }

        private static string DefaultPage(HttpListenerResponse resp)
        {
            string pageData =
           @"<!DOCTYPE>" +
           "<html>" +
           "  <head>" +
           "    <title>HttpPrinter </title>" +
           "<meta http-equiv=\"Content-type\" content=\"text/html; charset=utf-8\" />" +
           "  </head>" +
           "<script>" + 
           "   function loadPrinters() {" + 
           "     var xhttp = new XMLHttpRequest();  " + 
           "      xhttp.onreadystatechange = function() {" + 
           "      if (this.readyState == 4 && this.status == 200) {" + 
           "        document.getElementById(\"printerList\").innerHTML = this.responseText;" +
           "      }" +
           "    };" + 
           "    xhttp.open(\"GET\", \"/printers/\", true);  " +
           "    xhttp.send();" + 
           "  }" +
           "</script>" +
           "  <body>" +
           " <p>printer list: <span id=\"printerList\"></span></p>" +
           "<script>" +
           "loadPrinters();" +
           "</script>" +
           "    <form method=\"post\" action=\"print\" accept-charset=\"utf-8\">" +
          "        <input type =\"hidden\" name=\"Reference\" value=\"asdf\" /><br/>" +
          "        < input type =\"hidden\" name=\"Preview\" value=\"true\" /><br/>" +
         "       Title : <input type =\"text\" name=\"Title\" value=\"\" /><br/>" +
           "     Body: <textarea rows=\"10\" cols=\"80\" name=\"Content\" ></textarea><br/>" +
           "     Barcode  <input type =\"text\" name=\"BarcodeData\" value=\"\" /><br/>" +
          "     Type  <select  name=\"Type\" ><option value=\"RCPT\">R</option><option value=\"APSL\">A</option></select><br/>" +
           "      <input type=\"submit\" value=\"Print\"/><br/>" +
           "    </form>" +
           "  </body>" +
           "</html>";
            resp.ContentType = "text/html";
            return pageData;
        }

        internal void Close()
        {
            listener.Close();
        }
    }
    

    public class PrintResponse
    {
        public string Status { get; set; }
        public string Printer { get; set; }
        public string Reference { get; set; }
    }

    public class ErrorResponse
    {
        public string Message { get; set; }
    }

    public class PrintRequestEventArgs : EventArgs
    {
        public PrintRequest Request { get; set; }
        public PrintResponse Response { get; set; }
    }
}
